rm(list = ls())
ls()

plus7 = function(x)
{x+7}

